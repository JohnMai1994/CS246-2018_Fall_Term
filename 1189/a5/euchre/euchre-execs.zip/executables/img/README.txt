https://gallery.yopriceville.com/Free-Clipart-Pictures/Decorative-Elements-PNG/Card_Suits_Transparent_Clip_Art_Image#.Wuxo3ci1vOQ
is the source for the suit images {H,C,D,S}.png

Question mark for "no suit" (N.png) comes from https://www.publicdomainpictures.net/en/view-image.php?image=128404&picture=question-mark

Celebration image comes from http://oozed.info/celebrate-clip-art/celebrate-clip-art-free-celebration-clip-art-pictures-clipartix/

Picard face palm https://imgur.com/gallery/iWKad22

Game Over and Oops! from https://www.123rf.com/profile_noravector

Explosion from <a href='https://www.freepik.com/free-vector/word-pow-with-bomb-explosive_1250787.htm'>Designed by Freepik</a>
